const { Router } = require('express');
const configuracaoIAController = require('../controllers/configuracaoIA.controller');

const router = Router();

router.get('/', configuracaoIAController.obter);
router.put('/', configuracaoIAController.salvar);

module.exports = router;
