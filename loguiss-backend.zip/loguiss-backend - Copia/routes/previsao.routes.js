const { Router } = require('express');
const previsaoController = require('../controllers/previsao.controller');

const router = Router();

router.post('/', previsaoController.gerar);
router.get('/ultima', previsaoController.ultima); // precisa vir antes de "/:id"
router.get('/:id', previsaoController.obter);

module.exports = router;
