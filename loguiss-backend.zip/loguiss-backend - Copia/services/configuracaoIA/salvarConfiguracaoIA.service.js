const prisma = require('../../lib/prisma');
const { validarConfiguracaoIA } = require('../../utils/configuracaoIA');

// Aceita só os campos enviados (ex.: mudar apenas o intervalo).
async function salvarConfiguracaoIA(corpo) {
  const dados = validarConfiguracaoIA(corpo);

  return prisma.configuracao_ia.upsert({
    where: { id_configuracao_ia: 1 },
    update: dados,
    create: { id_configuracao_ia: 1, ...dados },
  });
}

module.exports = { salvarConfiguracaoIA };
