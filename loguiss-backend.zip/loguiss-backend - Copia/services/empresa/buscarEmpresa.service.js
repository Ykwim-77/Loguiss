const prisma = require('../../lib/prisma');

// Cada banco tem uma empresa só, então sempre buscamos o primeiro registro.
async function buscarEmpresa() {
  return prisma.empresa.findFirst();
}

module.exports = { buscarEmpresa };
