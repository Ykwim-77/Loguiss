/**
 * Fluxo completo de uma previsão nova:
 *   configuração e empresa → dados do banco → IA (contexto) → IA (previsão)
 *   → contas no Node → salvar → devolver no formato do front.
 *
 * Usado pela rota manual (POST /previsoes) e pelo agendador automático.
 */
const { erroHttp } = require('../../utils/erros');
const { HORIZONTES_VALIDOS } = require('../../utils/previsao/constantes');
const calc = require('../../utils/previsao/calculos');
const { buscarConfiguracaoIA } = require('../configuracaoIA/buscarConfiguracaoIA.service');
const { buscarEmpresa } = require('../empresa/buscarEmpresa.service');
const { montarDadosPrevisao } = require('./montarDadosPrevisao.service');
const { consultarContextoIA } = require('./consultarContextoIA.service');
const { consultarPrevisaoIA } = require('./consultarPrevisaoIA.service');
const { salvarPrevisao } = require('./salvarPrevisao.service');
const { buscarPrevisao } = require('./buscarPrevisao.service');

// Evita duas gerações ao mesmo tempo (cada uma gasta tempo e dinheiro de IA).
let gerandoAgora = false;

/**
 * opcoes (todas opcionais): { horizonteDias, localizacao, segmento, idsProdutos }
 * Sem horizonteDias, usa o da configuração da IA.
 */
async function gerarPrevisao(opcoes = {}) {
  if (gerandoAgora) {
    throw erroHttp(409, 'Já existe uma previsão sendo gerada. Aguarde terminar.', 'JA_GERANDO');
  }

  gerandoAgora = true;
  try {
    const config = await buscarConfiguracaoIA();

    const horizonteDias = Number(opcoes.horizonteDias ?? config.horizonte_dias);
    if (!HORIZONTES_VALIDOS.includes(horizonteDias)) {
      throw erroHttp(
        400,
        `horizonteDias deve ser um destes valores: ${HORIZONTES_VALIDOS.join(', ')}.`,
        'HORIZONTE_INVALIDO'
      );
    }

    const empresa = await buscarEmpresa();
    const descricao = calc.descreverEmpresa(empresa);
    if (!descricao.completo) {
      console.warn('[previsao] cidade, UF ou segmento não cadastrados na empresa: a pesquisa da IA ficará genérica.');
    }
    const localizacao = String(opcoes.localizacao || descricao.localizacao).trim();
    const segmento = String(opcoes.segmento || descricao.segmento).trim();
    const idsProdutos = Array.isArray(opcoes.idsProdutos)
      ? opcoes.idsProdutos.map(Number).filter(Number.isInteger)
      : [];

    const dados = await montarDadosPrevisao({
      horizonteDias,
      idsProdutos,
      prazoPadraoDias: config.prazo_reposicao_padrao_dias,
    });

    const contexto = await consultarContextoIA({ ...dados, localizacao, segmento });
    const previsao = await consultarPrevisaoIA({ ...dados, contexto: contexto.contexto });

    const linhas = calc.montarLinhas(dados.entradas, previsao.previsoes);
    const alertas = calc.consolidarAlertas(linhas, previsao.alertasIA);

    const idPrevisao = await salvarPrevisao({
      horizonteDias,
      modelo: contexto.modelo ?? previsao.modelo,
      localizacao,
      segmento,
      contexto: contexto.contexto,
      contextoBruto: contexto.bruto,
      dadosEnviados: previsao.dadosEnviados,
      respostasBrutas: previsao.respostasBrutas,
      linhas,
      alertas,
    });

    return await buscarPrevisao({ id: idPrevisao });
  } finally {
    gerandoAgora = false;
  }
}

module.exports = { gerarPrevisao };
