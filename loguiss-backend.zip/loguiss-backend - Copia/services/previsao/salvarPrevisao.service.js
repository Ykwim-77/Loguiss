const prisma = require('../../lib/prisma');

/** Salva a previsão, os produtos, a série diária e os alertas numa transação só. Devolve o id. */
async function salvarPrevisao({
  horizonteDias,
  modelo,
  localizacao,
  segmento,
  contexto,
  contextoBruto,
  dadosEnviados,
  respostasBrutas,
  linhas,
  alertas,
}) {
  return prisma.$transaction(
    async (tx) => {
      const criada = await tx.previsao.create({
        data: {
          horizonte_dias: horizonteDias,
          modelo: modelo ?? 'desconhecido',
          localizacao,
          segmento,
          contexto,
          dados_enviados: { lotes: dadosEnviados },
          resposta_bruta: { contexto: contextoBruto, lotes: respostasBrutas },
        },
      });

      for (const { entrada, previsao, recomendacao } of linhas) {
        await tx.previsao_produto.create({
          data: {
            id_previsao: criada.id_previsao,
            id_produto: entrada.id_produto,
            estoque_na_data: entrada.estoque_atual,
            estoque_seguro: entrada.estoque_seguro,
            prazo_reposicao_dias: entrada.prazo_reposicao_dias,
            media_dia: recomendacao.media_dia,
            total_previsto: recomendacao.total_previsto,
            confianca: previsao.confianca,
            justificativa: previsao.justificativa,
            cobertura_dias: recomendacao.cobertura_dias,
            dias_para_comprar: recomendacao.dias_para_comprar,
            urgente: recomendacao.urgente,
            comprar_qtd: recomendacao.comprar_qtd,
            periodos: {
              create: previsao.serie.map((dia) => ({
                data: new Date(`${dia.data}T00:00:00Z`),
                quantidade: dia.quantidade,
              })),
            },
          },
        });
      }

      if (alertas.length) {
        await tx.alerta.createMany({
          data: alertas.map((a) => ({ ...a, id_previsao: criada.id_previsao })),
        });
      }

      return criada.id_previsao;
    },
    { maxWait: 10000, timeout: 60000 }
  );
}

module.exports = { salvarPrevisao };
