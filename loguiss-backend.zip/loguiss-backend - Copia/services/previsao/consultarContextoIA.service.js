const prompts = require('../../utils/previsao/prompts');
const calc = require('../../utils/previsao/calculos');
const { consultarJsonValidado } = require('../../utils/previsao/consultarJsonValidado');

/**
 * Passo 1 da IA: ela pesquisa na web eventos, feriados e sazonalidade
 * para a localização e o segmento da empresa.
 */
async function consultarContextoIA({
  hoje,
  dataInicioPrevisao,
  dataFimPrevisao,
  horizonteDias,
  localizacao,
  segmento,
  entradas,
}) {
  try {
    const categorias = [...new Set(entradas.map((e) => e.categoria))];

    const resposta = await consultarJsonValidado(
      {
        system: prompts.SYSTEM_CONTEXTO,
        usuario: prompts.montarMensagemContexto({
          dataReferencia: hoje,
          dataInicio: dataInicioPrevisao,
          dataFim: dataFimPrevisao,
          horizonteDias,
          localizacao,
          segmento,
          categorias,
        }),
        usarBuscaWeb: true,
        maxTokens: 3000,
      },
      calc.validarContexto
    );

    return { contexto: resposta.dados, bruto: resposta.bruto, modelo: resposta.modelo };
  } catch (erro) {
    if (erro.codigo === 'IA_SEM_CHAVE') throw erro;

    // Sem o contexto a previsão ainda funciona, só que sem eventos e sazonalidade.
    console.warn(`[previsao] seguindo sem contexto: ${erro.message}`);
    return {
      contexto: { eventos: [], sazonalidade: '', fontes: [], indisponivel: true },
      bruto: null,
      modelo: null,
    };
  }
}

module.exports = { consultarContextoIA };
