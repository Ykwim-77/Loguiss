module.exports = {
  // Quantos dias a IA pode prever (o usuário escolhe um destes na configuração)
  HORIZONTES_VALIDOS: [5, 10, 14, 30],

  // De quantos em quantos minutos pode haver consulta automática à IA.
  // O mínimo existe para proteger o custo: cada consulta usa a IA de verdade.
  INTERVALO_MINIMO_MINUTOS: 15,
  INTERVALO_MAXIMO_MINUTOS: 43200, // 30 dias

  PRAZO_REPOSICAO_MINIMO_DIAS: 1,
  PRAZO_REPOSICAO_MAXIMO_DIAS: 60,

  DIAS_HISTORICO: 60, // quantos dias de saídas são enviados à IA
  PRODUTOS_POR_LOTE: 10, // produtos por chamada de previsão
  MAX_ALERTAS_POR_PRODUTO: 3,
};
