/**
 * Único arquivo que fala com o provedor de IA (Anthropic).
 * Para trocar de provedor, só este arquivo precisa mudar: o resto do código
 * chama consultarIA() e recebe { texto, modelo }.
 *
 * Precisa de Node 18+ (usa fetch nativo). A chave vem de ANTHROPIC_API_KEY.
 */
const { erroHttp } = require('./erros');

const API_URL = 'https://api.anthropic.com/v1/messages';
const VERSAO_API = '2023-06-01';
const MAX_CONTINUACOES = 3;

// Lê as variáveis na hora da chamada, assim o dotenv já foi carregado.
function config() {
  return {
    apiKey: process.env.ANTHROPIC_API_KEY,
    modelo: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
    timeoutMs: Number(process.env.IA_TIMEOUT_MS || 120000),
  };
}

async function chamarApi(corpo, { apiKey, timeoutMs }) {
  const controlador = new AbortController();
  const timer = setTimeout(() => controlador.abort(), timeoutMs);

  let resposta;
  try {
    resposta = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': VERSAO_API,
      },
      body: JSON.stringify(corpo),
      signal: controlador.signal,
    });
  } catch (erro) {
    if (erro.name === 'AbortError') {
      throw erroHttp(504, 'A IA demorou demais para responder.', 'IA_TIMEOUT');
    }
    throw erroHttp(502, `Não foi possível falar com a IA: ${erro.message}`, 'IA_INDISPONIVEL');
  } finally {
    clearTimeout(timer);
  }

  const dados = await resposta.json().catch(() => null);

  if (!resposta.ok) {
    const detalhe = dados?.error?.message || `HTTP ${resposta.status}`;
    throw erroHttp(502, `Erro da API de IA: ${detalhe}`, 'IA_ERRO_API');
  }

  return dados;
}

/**
 * Envia um prompt e devolve o texto da resposta.
 * usarBuscaWeb = true liga a ferramenta de busca na web, que é o que faz a IA
 * pesquisar eventos e sazonalidade sozinha.
 */
async function consultarIA({ system, usuario, usarBuscaWeb = false, maxTokens = 4096 }) {
  const cfg = config();

  if (!cfg.apiKey) {
    throw erroHttp(
      500,
      'Chave da IA não configurada. Defina ANTHROPIC_API_KEY no .env.',
      'IA_SEM_CHAVE'
    );
  }

  const messages = [{ role: 'user', content: usuario }];
  const corpo = { model: cfg.modelo, max_tokens: maxTokens, system, messages };

  if (usarBuscaWeb) {
    corpo.tools = [
      {
        type: 'web_search_20250305',
        name: 'web_search',
        max_uses: 5,
        user_location: { type: 'approximate', country: 'BR', timezone: 'America/Sao_Paulo' },
      },
    ];
  }

  let resposta = await chamarApi(corpo, cfg);

  // Em turnos longos com busca, a API pode pausar (pause_turn).
  // Para continuar, devolvemos o conteúdo recebido como mensagem do assistente.
  for (let i = 0; i < MAX_CONTINUACOES && resposta.stop_reason === 'pause_turn'; i++) {
    messages.push({ role: 'assistant', content: resposta.content });
    resposta = await chamarApi(corpo, cfg);
  }

  // Une com '' (e não com quebra de linha) porque, com busca web, o JSON
  // pode vir dividido em vários blocos de texto.
  const texto = (resposta.content || [])
    .filter((bloco) => bloco.type === 'text')
    .map((bloco) => bloco.text)
    .join('');

  return { texto, modelo: resposta.model || cfg.modelo, uso: resposta.usage };
}

/** Extrai o objeto JSON de dentro do texto, mesmo se vier com markdown ou frases antes/depois. */
function extrairJson(texto) {
  if (!texto || !texto.trim()) {
    throw new Error('A IA não retornou texto.');
  }

  const limpo = texto.replace(/```json|```/gi, '');
  const inicio = limpo.indexOf('{');
  const fim = limpo.lastIndexOf('}');

  if (inicio === -1 || fim <= inicio) {
    throw new Error('Não encontrei um JSON na resposta da IA.');
  }

  try {
    return JSON.parse(limpo.slice(inicio, fim + 1));
  } catch (erro) {
    throw new Error(`JSON inválido na resposta da IA: ${erro.message}`);
  }
}

module.exports = { consultarIA, extrairJson };
