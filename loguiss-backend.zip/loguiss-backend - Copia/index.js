import express from 'express';
import cors from 'cors';
import router_login from './routes/routes_login.js';
import router_categoria from './routes/routes_categoria.js';
import router_receita from './routes/routes_receita.js';
import router_produto from './routes/routes_produto.js';
import router_fornecedor from './routes/routes_fornecedor.js';
import router_unidade_medida from './routes/routes_unidade_medida.js';
import router_cliente from './routes/routes_clientes.js';
import router_user from './routes/routes_user.js';
import router_movimentacao from './routes/routes_movimentacao.js';
import router_dashboard from './routes/router_dashboard.js';
import router_empresa from './routes/routes_empresa.js';

const app = express();

app.use(express.json());
app.use(cors());
app.use("/login", router_login);
app.use("/categoria", router_categoria);
app.use("/receita", router_receita);
app.use("/produto", router_produto);
app.use("/fornecedor", router_fornecedor);
app.use("/unidade_medida", router_unidade_medida);
app.use("/cliente", router_cliente);
app.use("/user", router_user);
app.use("/movi", router_movimentacao);
app.use("/dashboard", router_dashboard);
app.use("/empresa", router_empresa);


app.listen(3000);